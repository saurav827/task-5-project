<?php
$mysqli = new mysqli('localhost', 'root', '', 'crud_app');
?>