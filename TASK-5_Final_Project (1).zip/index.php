<?php include 'includes/header.php'; ?>
<h2>Welcome to Final Project</h2>
<?php include 'includes/footer.php'; ?>